export default function FeedPage() {
  return (
    <div>
      <h1>Community Feed</h1>
      <p style={{ color: '#ccc' }}>Discover public racks and patches from the community.</p>
    </div>
  );
}
