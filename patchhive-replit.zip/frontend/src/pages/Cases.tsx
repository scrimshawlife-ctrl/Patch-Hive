/**
 * Cases page - placeholder.
 */
export default function CasesPage() {
  return (
    <div>
      <h1>Cases</h1>
      <p style={{ color: '#ccc' }}>Browse and manage Eurorack cases.</p>
    </div>
  );
}
