export default function PatchesPage() {
  return (
    <div>
      <h1>Patches</h1>
      <p style={{ color: '#ccc' }}>Explore generated patches.</p>
    </div>
  );
}
