export default function RackBuilderPage() {
  return (
    <div>
      <h1>Rack Builder</h1>
      <p style={{ color: '#ccc' }}>Design your Eurorack system.</p>
    </div>
  );
}
