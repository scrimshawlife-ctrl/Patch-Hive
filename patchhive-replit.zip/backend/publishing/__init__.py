"""Publishing module for public artifacts."""
