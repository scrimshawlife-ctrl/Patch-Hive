"""
External integrations for PatchHive.
"""
