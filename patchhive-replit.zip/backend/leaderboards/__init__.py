"""Leaderboards domain - aggregate module stats."""
