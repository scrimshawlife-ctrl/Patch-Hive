"""Patches domain - Patch generation, storage, and visualization."""

from .models import Patch

__all__ = ["Patch"]
