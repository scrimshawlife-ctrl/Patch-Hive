"""Modules domain - Eurorack module catalog and management."""

from .models import Module

__all__ = ["Module"]
