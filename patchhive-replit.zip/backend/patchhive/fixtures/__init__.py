"""Deterministic fixtures for PatchHive."""

from .basic_voice_fixture import gallery_voice_entry, rigspec_voice_min

__all__ = [
    "gallery_voice_entry",
    "rigspec_voice_min",
]
