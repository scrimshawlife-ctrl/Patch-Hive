"""PatchHive tests."""
