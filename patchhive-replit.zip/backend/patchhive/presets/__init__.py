"""Library presets for patch generation."""
