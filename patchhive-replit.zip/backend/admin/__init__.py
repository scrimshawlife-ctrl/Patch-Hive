"""Admin module for audit logging."""
