"""
PatchHive backend tests.
"""
