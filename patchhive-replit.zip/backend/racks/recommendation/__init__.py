"""Rack recommendation package."""
